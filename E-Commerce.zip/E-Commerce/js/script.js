// Toggle class active
const navbarNav = document.querySelector(".navbar-nav");
//ketika hamburger diklik
document.querySelector("#hamburger-menu").onclick = () => {
  navbarNav.classList.toggle("active");
};

// Klik diluar sidebar untuk menghilangkan nav
const hamburger = document.querySelector("#hamburger-menu");

document.addEventListener("click", function (e) {
  if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
    navbarNav.classList.remove("active");
  }
});
// ===== Form Kontak Validasi =====
const contactForm = document.querySelector(".contact form");

if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const inputs = contactForm.querySelectorAll("input");
    let valid = true;

    inputs.forEach((input) => {
      if (input.value.trim() === "") {
        input.style.borderBottom = "1px solid red";
        valid = false;
      } else {
        input.style.borderBottom = "1px solid var(--primary)";
      }
    });

    if (valid) {
      alert("Pesan berhasil dikirim!");
      contactForm.reset();
    } else {
      alert("Mohon lengkapi semua data terlebih dahulu.");
    }
  });
}
const waButton = document.querySelector(".wa-float");
let lastScrollTop = 0;

window.addEventListener("scroll", () => {
  let scrollTop = window.scrollY || document.documentElement.scrollTop;
  if (scrollTop > lastScrollTop) {
    // Scroll ke bawah, sembunyikan
    waButton.style.opacity = "0";
  } else {
    // Scroll ke atas, tampilkan
    waButton.style.opacity = "1";
  }
  lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});
